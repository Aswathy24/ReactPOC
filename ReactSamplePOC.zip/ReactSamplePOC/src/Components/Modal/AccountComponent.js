import React, { useState, useContext, useEffect } from "react";
import { Collapse} from "react-bootstrap";
import { Input } from "reactstrap";
import "./modalStyles.css";
import { UserContext } from "../../App";
import { getCoList, handleValues ,getObaList} from "../utils";

import { FaAngleUp } from "react-icons/fa";


const AccountLister = (groups) =>{

    const { templateList, setTemplateList, coList, setCoList } =
    useContext(UserContext);

const [expand, setExpand] = useState({});
const [ acctobj, setAcctobj] = useState([]);
const [obj,setObj] = useState([]);
  const oba =   {

        "limit": 10,
        "offset": 1,
        "count": 50,
        "billtoList": [
            {
                "accountId": 1111,
                "obaNumber": "OBA-1111",
                "legacyAccNum": null,
                "accountType": "BILL-TO",
                "efxId": "223232",
                "legalName": "ABCD",
                "accountStatusDesc": "active",
                "accountStatus": 27,
                "companyNumber": "0210",
                "billtoId": null,
                "shiptoList": [
                    {
                        "accountId": 2222,
                        "obaNumber": "OBA-2222",
                        "legacyAccNum": "spx777",
                        "accountType": "BILL-TO",
                        "efxId": "888888",
                        "legalName": "PQR",
                        "accountStatusDesc": "active",
                        "accountStatus": 27,
                        "companyNumber": "0210",
                        "billtoId": 1111,
                        "shiptoList": []
                    },
                    {
                        "accountId": 3333,
                        "obaNumber": "OBA-3333",
                        "legacyAccNum": "spx777",
                        "accountType": "BILL-TO",
                        "efxId": "888888",
                        "legalName": "PQR",
                        "accountStatusDesc": "active",
                        "accountStatus": 27,
                        "companyNumber": "0210",
                        "billtoId": 1111,
                        "shiptoList": []
                    
                    }
                ]
                
            },
            {
                "accountId": 4444,
                "obaNumber": "OBA-4444",
                "legacyAccNum": null,
                "accountType": "BILL-TO",
                "efxId": "223232",
                "legalName": "ABCD",
                "accountStatusDesc": "active",
                "accountStatus": 27,
                "companyNumber": "0210",
                "billtoId": null,
                "shiptoList": [
                    {
                        "accountId": 5555,
                        "obaNumber": "OBA-5555",
                        "legacyAccNum": "spx777",
                        "accountType": "BILL-TO",
                        "efxId": "888888",
                        "legalName": "PQR",
                        "accountStatusDesc": "active",
                        "accountStatus": 27,
                        "companyNumber": "0210",
                        "billtoId": 1111,
                        "shiptoList": []
                    },
                     {
                        "accountId": 6666,
                        "obaNumber": "OBA-6666",
                        "legacyAccNum": "spx777",
                        "accountType": "BILL-TO",
                        "efxId": "888888",
                        "legalName": "PQR",
                        "accountStatusDesc": "active",
                        "accountStatus": 27,
                        "companyNumber": "0210",
                        "billtoId": 1111,
                        "shiptoList": []
}
                ]
                 
                
            }
        ]
        
    };
  
    let obaList= [];
    let List = [];
    obaList = Array.from(oba.billtoList);
    console.log("obaList",obaList);
    console.log("groups",groups);

    useEffect(() => {
        oba.billtoList.map((ele,i) => expand[i] = true)
        setAcctobj(oba.billtoList);
        setObj(getObaList(obaList));
      }, [obaList.length])  ;

      List = obj;
      console.log("List",List);
console.log("Expand object",expand);

console.log("Account Object",acctobj);

console.log("Object",obj);


const handleAccountPanelCollapse = (i) => {
    console.log("Index",i);
    const obj = {...expand};
    console.log("Expand object before toggling--1",obj);
    obj[i] = !obj[i];
    setExpand({...obj});
    console.log("Expand object after toggling--2",obj);
 }

  
const handleCheckboxClick = (i,type) => {
       console.log("selectbox checked",type);
       const temp = JSON.parse(JSON.stringify(acctobj));
       console.log("Temp Object",temp);
       temp[i][type] = !temp[i][type];
       setAcctobj(temp);
 };


return (
        <li className="obaStyleli">
             {
              oba.billtoList.map((ele,i) => 
                <><div className="accountHeader">
                  <span>{ele.obaNumber}</span>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                
 <Input  style={{ borderRadius :'25px', padding: '5px', alignContent:'center'}}
                          name="check"
                          type="checkbox"
                          onClick={() => handleCheckboxClick(i, "isSelected")}
                          />
                   &nbsp;&nbsp;&nbsp;    
     <Input  style={{ borderRadius :'25px', padding: '5px', backgroundColor : 'green', alignContent:'center'}}
                          name="check"
                          type="checkbox"
                          />  
                      &nbsp;&nbsp;
<FaAngleUp  style={{  fontSize:'24px', color :'black' }}
                       onClick={() => {
                        handleAccountPanelCollapse(i);
                      }}
                      
                      />       
                </div>
  {ele.shiptoList.map((e,j) => 
                 <Collapse key= {j} in={expand[i]}>
                   <div className="accountItem">
                      <span>{e.obaNumber}</span>
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <div>
                           <span
                                className="AOunselected">
 AO
                           </span>
                           </div>
                           &nbsp;
                           <div>
                           <span
                                className="AOunselected">
                                DO
                           </span>
                           </div>
                   &nbsp;&nbsp;
                           <Input  style={{ borderRadius :'25px', padding: '8px', alignContent:'center',fontSize: '18.8px'}}
                          name="check"
                          type="checkbox"
                          /> 
                       
                      </div>
                      </Collapse>
                     )}
</>
                )}
             </li>
      );
}

export default AccountLister;

